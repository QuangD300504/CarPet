package com.example.vetbook.domain.repository

import com.example.vetbook.domain.models.CartLine
import com.example.vetbook.domain.models.StoreOrder
import com.example.vetbook.domain.models.StoreProduct
import kotlinx.coroutines.flow.Flow

interface StoreRepository {
    fun observeProducts(category: String? = null): Flow<List<StoreProduct>>
    fun observeCart(uid: String): Flow<List<CartLine>>
    suspend fun setCartQuantity(uid: String, productId: String, quantity: Int): Result<Unit>
    suspend fun clearCart(uid: String): Result<Unit>

    suspend fun addProduct(product: StoreProduct): Result<String>

    suspend fun updateProduct(product: StoreProduct): Result<Unit>

    suspend fun deleteProduct(productId: String): Result<Unit>

    // === Order observation ===
    fun observeOrders(uid: String): Flow<List<StoreOrder>>
    suspend fun getOrderById(orderId: String): StoreOrder?
}

