package com.example.vetbook.domain.models

/**
 * Species supported for auto-generated vaccination schedules.
 */
enum class VaccineSpecies {
    DOG,
    CAT,
}

/**
 * A vaccine template defines what dose(s) a pet should receive,
 * relative to their birth date. Used to auto-generate schedules.
 *
 * Templates come in 4 types:
 * - CORE: essential for all pets, pre-checked, non-dismissible
 * - REGIONAL: endemic-area core, pre-checked with location note
 * - LIFESTYLE: risk-based, unchecked by default
 * - NOT_RECOMMENDED: WSAVA-flagged, excluded from auto-generate, informational only
 */
data class VaccineTemplate(
    val name: String,
    val alsoKnownAs: String? = null,
    val type: VaccinationType,
    /** Days after birth when this dose is due. null = informational only (not_recommended). */
    val offsetDays: Int? = null,
    val isRecurring: Boolean = false,
    /** For recurring vaccines: days between doses. null if not recurring. */
    val intervalDays: Int? = null,
    /** Free-text reason this lifestyle vaccine is recommended. */
    val lifestyleTrigger: String? = null,
)

/**
 * WSAVA-aligned vaccine templates for dogs and cats.
 * Offset days are relative to birth date.
 */
object VaccineTemplates {

    val bySpecies: Map<VaccineSpecies, List<VaccineTemplate>> = mapOf(
        VaccineSpecies.DOG to listOf(
            // ── CORE ──────────────────────────────────────────────────
            VaccineTemplate(
                name = "DHPP #1",
                alsoKnownAs = "Distemper combo",
                type = VaccinationType.CORE,
                offsetDays = 42,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "DHPP #2",
                alsoKnownAs = "Distemper combo",
                type = VaccinationType.CORE,
                offsetDays = 70,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "DHPP #3",
                alsoKnownAs = "Distemper combo",
                type = VaccinationType.CORE,
                offsetDays = 112,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "DHPP booster",
                alsoKnownAs = "Distemper combo",
                type = VaccinationType.CORE,
                offsetDays = 365,
                isRecurring = true,
                intervalDays = 1095
            ),
            VaccineTemplate(
                name = "Rabies",
                alsoKnownAs = null,
                type = VaccinationType.CORE,
                offsetDays = 112,
                isRecurring = true,
                intervalDays = 365
            ),
            // ── REGIONAL ─────────────────────────────────────────────
            VaccineTemplate(
                name = "Leptospirosis #1",
                alsoKnownAs = "Lepto 4",
                type = VaccinationType.REGIONAL,
                offsetDays = 84,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "Leptospirosis #2",
                alsoKnownAs = "Lepto 4",
                type = VaccinationType.REGIONAL,
                offsetDays = 112,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "Leptospirosis booster",
                alsoKnownAs = "Lepto 4",
                type = VaccinationType.REGIONAL,
                offsetDays = 477,
                isRecurring = true,
                intervalDays = 365
            ),
            // ── LIFESTYLE ───────────────────────────────────────────
            VaccineTemplate(
                name = "Bordetella",
                alsoKnownAs = "Kennel cough",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 112,
                isRecurring = true,
                intervalDays = 365,
                lifestyleTrigger = "Boarding, kennels, grooming, or dog parks"
            ),
            VaccineTemplate(
                name = "Parainfluenza",
                alsoKnownAs = "CPiV",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 112,
                isRecurring = true,
                intervalDays = 365,
                lifestyleTrigger = "High-contact environments"
            ),
            VaccineTemplate(
                name = "Canine Flu H3N2",
                alsoKnownAs = "Dog flu",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 112,
                isRecurring = true,
                intervalDays = 365,
                lifestyleTrigger = "Frequent boarding or outbreak regions"
            ),
            VaccineTemplate(
                name = "Canine Flu H3N8",
                alsoKnownAs = "Dog flu (H3N8)",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 140,
                isRecurring = true,
                intervalDays = 365,
                lifestyleTrigger = "North America, high-contact environments"
            ),
            VaccineTemplate(
                name = "Lyme Disease",
                alsoKnownAs = "Borrelia",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 112,
                isRecurring = true,
                intervalDays = 365,
                lifestyleTrigger = "Tick-endemic regions"
            ),
            // ── NOT RECOMMENDED (informational only — never auto-generated) ──
            VaccineTemplate(
                name = "Canine Coronavirus",
                alsoKnownAs = "CCoV",
                type = VaccinationType.NOT_RECOMMENDED,
                offsetDays = null,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "Giardia",
                alsoKnownAs = "Giardia spp.",
                type = VaccinationType.NOT_RECOMMENDED,
                offsetDays = null,
                isRecurring = false,
                intervalDays = null
            ),
        ),
        VaccineSpecies.CAT to listOf(
            // ── CORE ──────────────────────────────────────────────────
            VaccineTemplate(
                name = "FVRCP #1",
                alsoKnownAs = "Cat combo",
                type = VaccinationType.CORE,
                offsetDays = 42,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "FVRCP #2",
                alsoKnownAs = "Cat combo",
                type = VaccinationType.CORE,
                offsetDays = 70,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "FVRCP #3",
                alsoKnownAs = "Cat combo",
                type = VaccinationType.CORE,
                offsetDays = 112,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "FVRCP booster",
                alsoKnownAs = "Cat combo",
                type = VaccinationType.CORE,
                offsetDays = 365,
                isRecurring = true,
                intervalDays = 1095
            ),
            VaccineTemplate(
                name = "Rabies",
                alsoKnownAs = null,
                type = VaccinationType.CORE,
                offsetDays = 112,
                isRecurring = true,
                intervalDays = 365
            ),
            // ── REGIONAL ─────────────────────────────────────────────
            VaccineTemplate(
                name = "FeLV #1",
                alsoKnownAs = "Feline leukemia",
                type = VaccinationType.REGIONAL,
                offsetDays = 56,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "FeLV #2",
                alsoKnownAs = "Feline leukemia",
                type = VaccinationType.REGIONAL,
                offsetDays = 84,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "FeLV booster",
                alsoKnownAs = "Feline leukemia",
                type = VaccinationType.REGIONAL,
                offsetDays = 449,
                isRecurring = true,
                intervalDays = 365
            ),
            // ── LIFESTYLE ───────────────────────────────────────────
            VaccineTemplate(
                name = "Bordetella",
                alsoKnownAs = "Kennel cough",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 112,
                isRecurring = true,
                intervalDays = 365,
                lifestyleTrigger = "Multi-cat households, boarding"
            ),
            VaccineTemplate(
                name = "Chlamydia felis",
                alsoKnownAs = "Chlamydophila",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 112,
                isRecurring = true,
                intervalDays = 365,
                lifestyleTrigger = "Catteries or confirmed chlamydial history"
            ),
            VaccineTemplate(
                name = "FIV",
                alsoKnownAs = "Feline immunodeficiency",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 112,
                isRecurring = false,
                intervalDays = null,
                lifestyleTrigger = "Outdoor cats in high-prevalence areas"
            ),
            VaccineTemplate(
                name = "FIP",
                alsoKnownAs = "Feline peritonitis",
                type = VaccinationType.LIFESTYLE,
                offsetDays = 112,
                isRecurring = false,
                intervalDays = null,
                lifestyleTrigger = "Multi-cat households, limited availability"
            ),
            // ── NOT RECOMMENDED (informational only — never auto-generated) ──
            VaccineTemplate(
                name = "Microsporum canis",
                alsoKnownAs = "Ringworm vaccine",
                type = VaccinationType.NOT_RECOMMENDED,
                offsetDays = null,
                isRecurring = false,
                intervalDays = null
            ),
            VaccineTemplate(
                name = "Giardia (feline)",
                alsoKnownAs = "Giardia spp.",
                type = VaccinationType.NOT_RECOMMENDED,
                offsetDays = null,
                isRecurring = false,
                intervalDays = null
            ),
        ),
    )

    /**
     * Returns templates that can be auto-generated for a given species.
     * Excludes: NOT_RECOMMENDED and templates with null offsetDays.
     */
    fun generatableFor(species: VaccineSpecies): List<VaccineTemplate> =
        bySpecies[species].orEmpty().filter {
            it.type != VaccinationType.NOT_RECOMMENDED && it.offsetDays != null
        }

    /**
     * Returns the species enum value matching a pet type string.
     * Matches "dog", "Dog", "chó", "cat", "Cat", "mèo" (case-insensitive).
     */
    fun speciesFromPetType(petType: String): VaccineSpecies? = when (petType.lowercase()) {
        "dog", "chó", "cho" -> VaccineSpecies.DOG
        "cat", "mèo", "meo" -> VaccineSpecies.CAT
        else -> null
    }
}
