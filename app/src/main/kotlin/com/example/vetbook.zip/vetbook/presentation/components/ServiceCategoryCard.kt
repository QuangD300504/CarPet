package com.example.vetbook.presentation.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.vetbook.domain.models.ServiceCategory

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ServiceCategoryCard(
    category: ServiceCategory,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            androidx.compose.material3.Icon(
                imageVector = com.example.vetbook.presentation.utils.getCategoryIcon(category.id),
                contentDescription = null,
                modifier = Modifier.size(48.dp),
                tint = com.example.vetbook.presentation.theme.Brand
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column {
                Text(
                    text = category.title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text(
                    text = category.shortDescription,
                    fontSize = 13.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ServiceCategoryCardPreview() {
    ServiceCategoryCard(
        category = ServiceCategory("1", "Veterinary", "24/7 smart booking", com.example.vetbook.R.drawable.checkup),
        onClick = {}
    )
}